#ifndef TASK_H
#define TASK_H
#include "graphics.h"

struct Point
{
   int x;
   int y;
};

extern int left, top, width, height;


bool gen_points(IMAGE*, int, int, int, int, Point*, int);
void solution(Point *arr, int n, int *p1, int *p2, int *p3);
void save();

#endif
