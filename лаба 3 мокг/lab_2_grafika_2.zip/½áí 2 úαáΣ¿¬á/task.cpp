#include "task.h"
#include "graphics.h"
#include <iostream>
#include <time.h>
#include <cmath>


int random(int min, int max)
{
   return rand() % (max+1 - min) + min;
}

bool gen_points(IMAGE* img, int left, int top, int width, int height, Point *arr, int n)
{
   
    putimage(0, 0, img, COPY_PUT, width, height);
    setfillstyle(SOLID_FILL, WHITE);
    setcolor(WHITE); // ���� ��� ������� (��������� YELLOW �� BLUE, RED, CYAN, GREEN � �.�)
    srand(time(0));

    for (int i = 0; i < n; i++)
    {
        arr[i].x = random(left, left+width);
        arr[i].y = random(top, top+height-100);
        fillellipse(arr[i].x, arr[i].y, 2, 2); // ������� ����� (�������) ����� �������� � �����
    }

    return true;
}

void solution(Point *arr, int n, int *p1, int *p2, int *p3)
{
    double L = -1;
    for (int i = 0; i < n; i++)
    {
        for (int j = 1; j < n; j++)
        {
            for (int k = 2; k < n; k++)
            {
                if (i != j && j != k && k != i)
                {
                    double a = sqrt(pow(arr[i].x-arr[j].x,2)+pow(arr[i].y-arr[j].y,2));
                    double b = sqrt(pow(arr[i].x-arr[k].x,2)+pow(arr[i].y-arr[k].y,2));
                    double c = sqrt(pow(arr[j].x-arr[k].x,2)+pow(arr[j].y-arr[k].y,2));
                    double P = a+b+c;
                    if ((L == -1) || (P < L)) { L = P; *p1 = i; *p2 = j; *p3 = k; }
                }
            }
        }
    }
}

void save()
{
    int w, h;
    IMAGE *output;

    w  = getmaxx() + 1;
    h = getmaxy() + 1;
    output = createimage(w, h);

    getimage(0, 0, w - 1, h - 1, output);
    saveBMP("output.bmp", output);
    freeimage(output);
}

