#include <iostream>

#include "graphics.h"
#include "control.h"
#include "task.h"

const int n_POINTS = 20; 

int main()
{
    int winWidth = 800; 
    int winHeight = 570;

    initwindow(winWidth, winHeight);
   

    int left = 0;
    int top = 0;
    int width = winWidth;
    int height = winHeight-70;

      IMAGE *back;
    back = loadBMP("background.jpg");
    putimage(0, 0, back, COPY_PUT, width, height);

    create_control(GEN_POINTS, 200, winHeight-70, "generate.bmp");
    create_control(SOLVE,   300, winHeight-70, "solve.bmp");
    create_control(SAVE,   400, winHeight-70, "save.bmp");
    create_control(EXIT,   500, winHeight-70, "exit.bmp");

   
    bool isGenerated = false;
    Point arr[n_POINTS];

    while (true)
    {
        while (mousebuttons() != 1);

        switch (select_control())
        {
            case NONE:
                break;

            case GEN_POINTS:
            {
               isGenerated = gen_points(back,left, top, width, height, arr, n_POINTS);
               break;
            }

            case SOLVE:
            {
                if(isGenerated)
                {
                    int i,j,k;
                    solution(arr, n_POINTS, &i, &j, &k);
                    setcolor(WHITE); // ���� ��� ������� (��������� YELLOW �� BLUE, RED, CYAN, GREEN � �.�)

                    line(arr[i].x, arr[i].y, arr[j].x, arr[j].y);
                    line(arr[i].x, arr[i].y, arr[k].x, arr[k].y);
                    line(arr[j].x, arr[j].y, arr[k].x, arr[k].y);
                }
                break;
            }

            case SAVE:
            {
                save();
                break;
            }

            case EXIT:
            {
                closegraph();
                return 0;
            }
        }
    }
}
